let questions = [];
let currentIndex = 0;
let userAnswers = {};
let submittedQuestions = {};
let questionScores = {};
let totalScore = 0;
let isAnswerSubmitted = false;

let activeImportTab = 'docx';
let loadedDocxText = '';
let currentExamTitle = 'Ngân hàng mặc định (20 câu)';

const STORAGE_EXAM_KEY = 'tin12_custom_exam';
const STORAGE_TITLE_KEY = 'tin12_custom_exam_title';

document.addEventListener("DOMContentLoaded", () => {
  initNetworkStatusListener();
  registerServiceWorker();
  initExamData();
  setupModalEvents();
});

function initNetworkStatusListener() {
  const badge = document.getElementById("connection-badge");
  const banner = document.getElementById("offline-banner");

  function updateStatus() {
    if (navigator.onLine) {
      badge.textContent = "Trực tuyến";
      badge.className = "badge-online";
      if (banner) banner.classList.add("hidden");
    } else {
      badge.textContent = "Ngoại tuyến (Offline)";
      badge.className = "badge-offline";
      if (banner) banner.classList.remove("hidden");
    }
  }

  window.addEventListener("online", updateStatus);
  window.addEventListener("offline", updateStatus);
  updateStatus();
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js")
      .then((reg) => console.log("Service Worker đã sẵn sàng:", reg.scope))
      .catch((err) => console.warn("Lỗi đăng ký Service Worker:", err));
  }
}

async function initExamData() {
  const cachedCustom = localStorage.getItem(STORAGE_EXAM_KEY);
  const cachedTitle = localStorage.getItem(STORAGE_TITLE_KEY);

  if (cachedCustom) {
    try {
      const parsed = JSON.parse(cachedCustom);
      if (Array.isArray(parsed) && parsed.length > 0) {
        questions = parsed;
        currentExamTitle = cachedTitle || `Đề thi đã nạp (${questions.length} câu)`;
        updateExamStatusBar(true);
        renderQuestion(currentIndex);
        return;
      }
    } catch (e) {
      console.warn("Dữ liệu localStorage bị hỏng, tự động xóa và tải đề mặc định.", e);
      localStorage.removeItem(STORAGE_EXAM_KEY);
      localStorage.removeItem(STORAGE_TITLE_KEY);
    }
  }

  try {
    const res = await fetch("./questions.json");
    if (!res.ok) throw new Error("Lỗi tải tệp questions.json");
    questions = await res.json();
    currentExamTitle = `Ngân hàng mặc định (${questions.length} câu)`;
    updateExamStatusBar(false);
    renderQuestion(currentIndex);
  } catch (err) {
    console.error(err);
    document.getElementById("question-text").textContent =
      "Không thể tải dữ liệu câu hỏi. Vui lòng kiểm tra kết nối ở lần mở đầu tiên hoặc nạp đề thủ công.";
  }
}

function updateExamStatusBar(isCustom) {
  document.getElementById("exam-source-title").textContent = `Đề thi: ${currentExamTitle}`;
  const btnReset = document.getElementById("btn-reset-default");
  if (isCustom) {
    btnReset.classList.remove("hidden");
  } else {
    btnReset.classList.add("hidden");
  }
}

function resetToDefaultExam() {
  if (confirm("Bạn có muốn xóa đề thi đã nạp và khôi phục ngân hàng câu hỏi mặc định không?")) {
    localStorage.removeItem(STORAGE_EXAM_KEY);
    localStorage.removeItem(STORAGE_TITLE_KEY);
    currentIndex = 0;
    totalScore = 0;
    userAnswers = {};
    submittedQuestions = {};
    questionScores = {};
    document.getElementById("current-score-text").textContent = "Điểm: 0.00";
    document.getElementById("result-screen").classList.add("hidden");
    document.getElementById("quiz-card").classList.remove("hidden");
    document.getElementById("quiz-footer").classList.remove("hidden");
    initExamData();
  }
}

function renderQuestion(index) {
  if (!questions || questions.length === 0) return;

  const q = questions[index];
  const alreadySubmitted = Boolean(submittedQuestions[index]);
  isAnswerSubmitted = alreadySubmitted;

  const container = document.getElementById("options-container");
  const expBox = document.getElementById("explanation-box");
  const btnSubmit = document.getElementById("btn-submit");
  const btnNext = document.getElementById("btn-next");
  const btnPrev = document.getElementById("btn-prev");

  document.getElementById("progress-text").textContent = `Câu ${index + 1} / ${questions.length}`;
  const pct = Math.round(((index + 1) / questions.length) * 100);
  const progressFill = document.getElementById("progress-bar-fill");
  progressFill.style.width = `${pct}%`;
  progressFill.parentElement.setAttribute("aria-valuenow", String(pct));

  document.getElementById("question-topic").textContent = q.topic || "Tin học 12";
  document.getElementById("question-text").textContent = `Câu ${index + 1}: ${q.question}`;

  if (index > 0) {
    btnPrev.classList.remove("hidden");
  } else {
    btnPrev.classList.add("hidden");
  }

  if (q.type === "true_false") {
    document.getElementById("question-type-badge").textContent = "Đúng / Sai (1.0đ)";
    renderTrueFalseOptions(q, container, index, alreadySubmitted);
  } else {
    document.getElementById("question-type-badge").textContent = "Trắc nghiệm 4 lựa chọn";
    renderMultipleChoiceOptions(q, container, index, alreadySubmitted);
  }

  if (alreadySubmitted) {
    btnSubmit.classList.add("hidden");
    btnNext.classList.remove("hidden");
    btnNext.textContent = index === questions.length - 1 ? "Xem kết quả 🏆" : "Câu tiếp theo ❯";
    document.getElementById("explanation-text").textContent = q.explanation || "Không có giải thích chi tiết.";
    expBox.classList.remove("hidden");
  } else {
    expBox.classList.add("hidden");
    btnSubmit.classList.remove("hidden");
    btnSubmit.disabled = false;
    btnNext.classList.add("hidden");
  }
}

function renderMultipleChoiceOptions(q, container, qIndex, isLocked) {
  container.innerHTML = "";
  const userChoice = userAnswers[qIndex];

  q.options.forEach((optText, optIdx) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn-option";
    btn.innerHTML = `<b>${String.fromCharCode(65 + optIdx)}.</b> ${escapeHtml(optText)}`;

    if (userChoice === optIdx) btn.classList.add("selected");

    if (isLocked) {
      btn.disabled = true;
      if (optIdx === q.answer) btn.classList.add("correct");
      else if (optIdx === userChoice) btn.classList.add("wrong");
    } else {
      btn.onclick = () => {
        if (isAnswerSubmitted) return;
        document.querySelectorAll(".btn-option").forEach((b) => b.classList.remove("selected"));
        btn.classList.add("selected");
        userAnswers[qIndex] = optIdx;
      };
    }
    container.appendChild(btn);
  });
}

function renderTrueFalseOptions(q, container, qIndex, isLocked) {
  container.innerHTML = "";
  const group = document.createElement("div");
  group.className = "tf-group";

  if (!Array.isArray(userAnswers[qIndex])) {
    userAnswers[qIndex] = new Array(q.items.length).fill(null);
  }

  q.items.forEach((item, itemIdx) => {
    const card = document.createElement("div");
    card.className = "tf-item-card";

    const stmt = document.createElement("div");
    stmt.className = "tf-statement";
    stmt.innerHTML = `<b>${escapeHtml(item.label)})</b> ${escapeHtml(item.statement)}`;
    card.appendChild(stmt);

    const btnGroup = document.createElement("div");
    btnGroup.className = "tf-btn-group";

    const chosen = userAnswers[qIndex][itemIdx];

    const btnTrue = document.createElement("button");
    btnTrue.type = "button";
    btnTrue.className = `btn-tf ${chosen === true ? 'active-true' : ''}`;
    btnTrue.textContent = "Đúng";

    const btnFalse = document.createElement("button");
    btnFalse.type = "button";
    btnFalse.className = `btn-tf ${chosen === false ? 'active-false' : ''}`;
    btnFalse.textContent = "Sai";

    if (isLocked) {
      btnTrue.disabled = true;
      btnFalse.disabled = true;
      if (item.answer === true) {
        btnTrue.classList.add("is-correct");
        if (chosen === false) btnFalse.classList.add("is-wrong");
      } else {
        btnFalse.classList.add("is-correct");
        if (chosen === true) btnTrue.classList.add("is-wrong");
      }
    } else {
      btnTrue.onclick = () => {
        if (isAnswerSubmitted) return;
        userAnswers[qIndex][itemIdx] = true;
        btnTrue.classList.add("active-true");
        btnFalse.classList.remove("active-false");
      };

      btnFalse.onclick = () => {
        if (isAnswerSubmitted) return;
        userAnswers[qIndex][itemIdx] = false;
        btnFalse.classList.add("active-false");
        btnTrue.classList.remove("active-true");
      };
    }

    btnGroup.appendChild(btnTrue);
    btnGroup.appendChild(btnFalse);
    card.appendChild(btnGroup);
    group.appendChild(card);
  });

  container.appendChild(group);
}

function handleSubmitAnswer() {
  if (isAnswerSubmitted || submittedQuestions[currentIndex]) {
    return;
  }

  const q = questions[currentIndex];
  const userAns = userAnswers[currentIndex];

  if (q.type === "true_false") {
    if (!Array.isArray(userAns) || userAns.some((val) => val === null)) {
      alert("Vui lòng chọn đầy đủ [Đúng] hoặc [Sai] cho tất cả các nhận định!");
      return;
    }
  } else {
    if (userAns === undefined || userAns === null) {
      alert("Vui lòng chọn một phương án trả lời!");
      return;
    }
  }

  isAnswerSubmitted = true;
  submittedQuestions[currentIndex] = true;

  const btnSubmit = document.getElementById("btn-submit");
  const btnNext = document.getElementById("btn-next");
  btnSubmit.disabled = true;
  btnSubmit.classList.add("hidden");
  btnNext.classList.remove("hidden");
  btnNext.textContent = currentIndex === questions.length - 1 ? "Xem kết quả 🏆" : "Câu tiếp theo ❯";

  const earnedScore = (q.type === "true_false")
    ? gradeTrueFalse(q, userAns)
    : gradeMultipleChoice(q, userAns);

  questionScores[currentIndex] = earnedScore;
  totalScore = Object.values(questionScores).reduce((sum, val) => sum + val, 0);
  document.getElementById("current-score-text").textContent = `Điểm: ${totalScore.toFixed(2)}`;

  const expBox = document.getElementById("explanation-box");
  document.getElementById("explanation-text").textContent = q.explanation || "Không có giải thích chi tiết.";
  expBox.classList.remove("hidden");
}

function gradeMultipleChoice(q, userChoice) {
  const buttons = document.querySelectorAll(".btn-option");
  buttons.forEach((btn, idx) => {
    btn.disabled = true;
    if (idx === q.answer) btn.classList.add("correct");
    else if (idx === userChoice) btn.classList.add("wrong");
  });
  return userChoice === q.answer ? 0.25 : 0;
}

function gradeTrueFalse(q, userChoices) {
  let correctCount = 0;
  const cards = document.querySelectorAll(".tf-item-card");

  q.items.forEach((item, idx) => {
    if (userChoices[idx] === item.answer) correctCount++;
    const buttons = cards[idx].querySelectorAll(".btn-tf");
    const [btnTrue, btnFalse] = buttons;
    btnTrue.disabled = true;
    btnFalse.disabled = true;

    if (item.answer === true) {
      btnTrue.classList.add("is-correct");
      if (userChoices[idx] === false) btnFalse.classList.add("is-wrong");
    } else {
      btnFalse.classList.add("is-correct");
      if (userChoices[idx] === true) btnTrue.classList.add("is-wrong");
    }
  });

  switch (correctCount) {
    case 1: return 0.1;
    case 2: return 0.25;
    case 3: return 0.5;
    case 4: return 1.0;
    default: return 0.0;
  }
}

function handlePrevQuestion() {
  if (currentIndex > 0) {
    currentIndex--;
    renderQuestion(currentIndex);
  }
}

function handleNextQuestion() {
  if (currentIndex < questions.length - 1) {
    currentIndex++;
    renderQuestion(currentIndex);
  } else {
    showFinalResults();
  }
}

function showFinalResults() {
  document.getElementById("quiz-card").classList.add("hidden");
  document.getElementById("quiz-footer").classList.add("hidden");
  document.getElementById("result-screen").classList.remove("hidden");

  const maxScore = questions.reduce((s, q) => s + (q.type === "true_false" ? 1.0 : 0.25), 0);
  const normalized = maxScore > 0 ? (totalScore / maxScore) * 10 : 0;
  const percent = maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0;

  document.getElementById("result-exam-name").textContent = currentExamTitle;
  document.getElementById("final-score").textContent = normalized.toFixed(1);
  document.getElementById("stat-raw-score").textContent = `${totalScore.toFixed(2)} / ${maxScore.toFixed(2)}`;
  document.getElementById("stat-percent").textContent = `${percent}%`;
  document.getElementById("stat-total-q").textContent = questions.length;

  let evalText = "Cần ôn tập thêm kiến thức nền tảng!";
  if (normalized >= 9.0) evalText = "Xuất sắc! Bạn đã nắm vững kiến thức Tin học 12.";
  else if (normalized >= 8.0) evalText = "Giỏi! Kết quả rất tốt, hãy rà soát lại các ý còn nhầm.";
  else if (normalized >= 6.5) evalText = "Khá! Tiếp tục luyện tập thêm để đạt điểm tối đa.";
  else if (normalized >= 5.0) evalText = "Đạt yêu cầu! Bạn nên xem kỹ phần giải thích từng câu.";

  document.getElementById("result-evaluation").textContent = evalText;
}

function restartQuiz() {
  currentIndex = 0;
  totalScore = 0;
  userAnswers = {};
  submittedQuestions = {};
  questionScores = {};
  isAnswerSubmitted = false;

  document.getElementById("current-score-text").textContent = "Điểm: 0.00";
  document.getElementById("result-screen").classList.add("hidden");
  document.getElementById("quiz-card").classList.remove("hidden");
  document.getElementById("quiz-footer").classList.remove("hidden");
  renderQuestion(currentIndex);
}

function restartWithShuffle() {
  for (let i = questions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [questions[i], questions[j]] = [questions[j], questions[i]];
  }
  restartQuiz();
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function setupModalEvents() {
  const btnOpen = document.getElementById("btn-open-import");
  if (btnOpen) btnOpen.onclick = openImportModal;
}

function openImportModal() {
  document.getElementById("import-modal").classList.remove("hidden");
  clearImportStatus();
}

function closeImportModal() {
  document.getElementById("import-modal").classList.add("hidden");
}

function switchImportTab(tab) {
  activeImportTab = tab;
  document.getElementById("tab-btn-docx").classList.toggle("active", tab === 'docx');
  document.getElementById("tab-btn-text").classList.toggle("active", tab === 'text');
  document.getElementById("tab-content-docx").classList.toggle("hidden", tab !== 'docx');
  document.getElementById("tab-content-text").classList.toggle("hidden", tab !== 'text');
  clearImportStatus();
}

function clearImportStatus() {
  const msgBox = document.getElementById("import-msg");
  const warnBox = document.getElementById("import-warnings");
  msgBox.className = "import-msg hidden";
  msgBox.textContent = "";
  warnBox.className = "import-warnings hidden";
  warnBox.innerHTML = "";
}

function decodeXmlEntities(str) {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

async function handleDocxFileSelect(event) {
  const file = event.target.files[0];
  if (!file) return;

  clearImportStatus();

  if (!file.name.toLowerCase().endsWith('.docx')) {
    showImportStatus("Định dạng tệp không hợp lệ! Vui lòng chọn tệp Word có đuôi .docx.", 'error');
    return;
  }

  document.getElementById("docx-filename-text").textContent = file.name;
  document.getElementById("docx-filename-badge").classList.remove("hidden");

  try {
    const arrayBuffer = await file.arrayBuffer();
    const extractedXml = await extractDocxDocumentXml(arrayBuffer);
    if (!extractedXml) {
      throw new Error("Tệp .docx không hợp lệ hoặc không chứa nội dung văn bản (word/document.xml).");
    }

    const paras = extractedXml.match(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g) || [];
    const lines = paras.map((p) => {
      const texts = p.match(/<w:t(?:\s[^>]*)?>([^<]*)<\/w:t>/g) || [];
      const rawLine = texts.map((t) => t.replace(/<[^>]+>/g, '')).join('');
      return decodeXmlEntities(rawLine);
    }).filter((line) => line.trim().length > 0);

    loadedDocxText = lines.join('
');
    if (!loadedDocxText.trim()) {
      throw new Error("Tệp Word trống, không có văn bản để phân tích.");
    }

    showImportStatus(`Đã đọc thành công tệp "${file.name}" (${lines.length} dòng). Nhấn "Phân tích & Bắt đầu làm bài" để tiếp tục.`, 'success');
  } catch (err) {
    console.error(err);
    loadedDocxText = '';
    showImportStatus("Lỗi đọc tệp Word: " + err.message, 'error');
  }
}

async function extractDocxDocumentXml(arrayBuffer) {
  const buffer = new Uint8Array(arrayBuffer);
  if (buffer.byteLength < 30 || buffer[0] !== 0x50 || buffer[1] !== 0x4b) {
    throw new Error("Tệp không đúng chuẩn nén ZIP của định dạng .docx.");
  }

  const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  let offset = 0;

  while (offset < buffer.byteLength - 30) {
    if (view.getUint32(offset, true) !== 0x04034b50) {
      offset++;
      continue;
    }

    const method = view.getUint16(offset + 8, true);
    const compSize = view.getUint32(offset + 18, true);
    const nameLen = view.getUint16(offset + 26, true);
    const extraLen = view.getUint16(offset + 28, true);

    const nameBytes = buffer.subarray(offset + 30, offset + 30 + nameLen);
    const fileName = new TextDecoder().decode(nameBytes);

    const dataStart = offset + 30 + nameLen + extraLen;
    const dataEnd = dataStart + compSize;

    if (fileName === 'word/document.xml') {
      const compData = buffer.subarray(dataStart, dataEnd);
      if (method === 0) {
        return new TextDecoder().decode(compData);
      } else if (method === 8) {
        const ds = new DecompressionStream('deflate-raw');
        const writer = ds.writable.getWriter();
        writer.write(compData);
        writer.close();
        const reader = ds.readable.getReader();
        const chunks = [];
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
        }
        const totalLen = chunks.reduce((a, c) => a + c.length, 0);
        const merged = new Uint8Array(totalLen);
        let pos = 0;
        for (const c of chunks) {
          merged.set(c, pos);
          pos += c.length;
        }
        return new TextDecoder().decode(merged);
      }
    }
    offset = dataEnd > offset ? dataEnd : offset + 1;
  }
  return null;
}

function parseExamText(rawText) {
  const validQuestions = [];
  const warnings = [];
  const text = rawText.replace(/
/g, '
').replace(//g, '
').trim();

  const questionBlocks = text
    .split(/(?=(?:^|
)\s*(?:Câu\s*\d+\s*[:.)-]|\d+\s*[.):]))/i)
    .map((b) => b.trim())
    .filter((b) => /^(?:Câu\s*\d+\s*[:.)-]|\d+\s*[.):])/i.test(b));

  questionBlocks.forEach((rawBlock, qIdx) => {
    let block = rawBlock;
    const headerMatch = block.match(/^(?:Câu\s*(\d+)|(\d+))\s*[:.)-]/i);
    const displayNum = headerMatch ? (headerMatch[1] || headerMatch[2]) : String(qIdx + 1);

    let explanation = '';
    const expMatch = block.match(/(?:^|
)\s*(?:Lời giải|Giải thích|HD|Hướng dẫn)\s*[:.-]\s*([\s\S]*)$/i);
    if (expMatch) {
      explanation = expMatch[1].trim();
      block = block.substring(0, expMatch.index).trim();
    }

    const hasSubItems = /(?:^|
)\s*a\s*[\).]/i.test(block) && /(?:^|
)\s*b\s*[\).]/i.test(block);

    if (hasSubItems) {
      const contextMatch = block.match(/^(?:Câu\s*\d+\s*[:.)-]?|\d+\s*[.):]?)\s*([\s\S]*?)(?=(?:
\s*a\s*[\).]))/i);
      const questionText = contextMatch ? contextMatch[1].trim() : '';

      const ansMap = {};
      const ansKeyMatch = block.match(/(?:^|
)\s*(?:Đáp án|Đ\/A|Key)\s*[:.-]\s*([\s\S]*?)$/i);
      if (ansKeyMatch) {
        const keyStr = ansKeyMatch[1];
        const tfMatches = keyStr.matchAll(/([a-d])\s*[:=-]\s*(Đúng|Sai|True|False|[ĐđSstTfF])(?=$|[\s,;.)])/gi);
        for (const m of tfMatches) {
          ansMap[m[1].toLowerCase()] = /^(?:đ|t)/i.test(m[2]);
        }
        block = block.substring(0, ansKeyMatch.index).trim();
      }

      const items = [];
      const missingLabels = [];
      const itemLabels = ['a', 'b', 'c', 'd'];

      itemLabels.forEach((lbl) => {
        const regex = new RegExp(`(?:^|\n)\s*${lbl}\s*[\).]\s*([\s\S]*?)(?=(?:\n\s*[a-d]\s*[\).])|$)`, 'i');
        const match = block.match(regex);
        if (match) {
          let stmt = match[1].trim();
          let resolvedAns = null;

          const inlineTag = stmt.match(/[\(\[]\s*(Đúng|Sai|True|False|Đ|S)\s*[\)\]]\s*\.?\s*$/i);
          if (inlineTag) {
            resolvedAns = /^(?:đ|t)/i.test(inlineTag[1]);
            stmt = stmt.substring(0, inlineTag.index).trim();
          } else if (ansMap[lbl] !== undefined) {
            resolvedAns = ansMap[lbl];
          }

          if (resolvedAns === null) {
            missingLabels.push(lbl);
          } else {
            items.push({ label: lbl, statement: stmt, answer: resolvedAns });
          }
        }
      });

      if (items.length < 4 || missingLabels.length > 0) {
        warnings.push(
          `Câu ${displayNum} (Đúng/Sai): Thiếu đáp án hoặc thiếu nhận định (${missingLabels.length ? 'chưa rõ đáp án ý ' + missingLabels.join(', ') : 'chỉ nhận diện được ' + items.length + '/4 ý'}).`
        );
        return;
      }

      validQuestions.push({
        id: validQuestions.length + 1,
        type: 'true_false',
        topic: 'Đề thi tự nạp',
        question: questionText || `Câu ${displayNum}`,
        items: items,
        explanation: explanation || 'Không có giải thích chi tiết.'
      });
    } else {
      let correctIdx = null;
      const ansMatch = block.match(/(?:^|
|\s)(?:Đáp án|Đ\/A|Chọn|Key)\s*[:.-]\s*([A-D])/i);
      if (ansMatch) {
        correctIdx = ansMatch[1].toUpperCase().charCodeAt(0) - 65;
        block = block.substring(0, ansMatch.index).trim();
      }

      const qTextMatch = block.match(/^(?:Câu\s*\d+\s*[:.)-]?|\d+\s*[.):]?)\s*([\s\S]*?)(?=(?:(?:
|\s{2,})A\s*[.):]))/i);
      const questionText = qTextMatch ? qTextMatch[1].trim() : '';

      const options = [];
      const optLabels = ['A', 'B', 'C', 'D'];
      optLabels.forEach((lbl, idx) => {
        const nextLabels = optLabels.slice(idx + 1).join('');
        const nextLookahead = nextLabels ? `(?=(?:(?:\n|\s{2,})[${nextLabels}]\s*[.):])|$)` : '$';
        const optRegex = new RegExp(`(?:^|\n|\s{2,})${lbl}\s*[.):]\s*([\s\S]*?)${nextLookahead}`, 'i');
        const match = block.match(optRegex);
        if (match) {
          options.push(match[1].trim());
        }
      });

      if (options.length < 4) {
        warnings.push(`Câu ${displayNum}: Chỉ nhận diện được ${options.length}/4 phương án A, B, C, D.`);
        return;
      }

      if (correctIdx === null || correctIdx < 0 || correctIdx >= options.length) {
        warnings.push(`Câu ${displayNum}: Chưa xác định được đáp án đúng (thiếu dòng "Đáp án: A/B/C/D").`);
        return;
      }

      validQuestions.push({
        id: validQuestions.length + 1,
        type: 'multiple_choice',
        topic: 'Đề thi tự nạp',
        question: questionText || `Câu ${displayNum}`,
        options: options,
        answer: correctIdx,
        explanation: explanation || 'Không có giải thích chi tiết.'
      });
    }
  });

  return { validQuestions, warnings };
}

function executeImport() {
  clearImportStatus();
  let textToParse = '';
  let title = '';

  if (activeImportTab === 'docx') {
    textToParse = loadedDocxText;
    const fn = document.getElementById("docx-filename-text").textContent;
    title = fn ? `Tệp Word "${fn}"` : 'Tệp Word đã nạp';
  } else {
    textToParse = document.getElementById("paste-text-input").value;
    title = 'Văn bản sao chép';
  }

  if (!textToParse || textToParse.trim().length === 0) {
    showImportStatus("Chưa có nội dung đề thi để phân tích! Vui lòng chọn tệp .docx hoặc dán văn bản.", 'error');
    return;
  }

  const { validQuestions, warnings } = parseExamText(textToParse);

  if (warnings.length > 0) {
    const warnBox = document.getElementById("import-warnings");
    warnBox.innerHTML = `<b>⚠️ Phát hiện ${warnings.length} câu chưa đạt chuẩn (không tự ý gán đáp án):</b><ul>` +
      warnings.map((w) => `<li>${escapeHtml(w)}</li>`).join('') +
      `</ul>`;
    warnBox.classList.remove("hidden");
  }

  if (validQuestions.length === 0) {
    showImportStatus("Không nạp được câu hỏi hợp lệ nào! Vui lòng kiểm tra lại định dạng câu hỏi và dòng Đáp án theo hướng dẫn phía trên.", 'error');
    return;
  }

  const newTitle = `${title} (${validQuestions.length} câu)`;

  try {
    localStorage.setItem(STORAGE_EXAM_KEY, JSON.stringify(validQuestions));
    localStorage.setItem(STORAGE_TITLE_KEY, newTitle);
  } catch (storageErr) {
    console.warn("Cảnh báo lưu localStorage:", storageErr);
    alert("Bộ nhớ trình duyệt đã đầy nên đề thi chỉ được dùng trong phiên hiện tại (không lưu bền vững sau khi đóng ứng dụng).");
  }

  questions = validQuestions;
  currentExamTitle = newTitle;

  const successMsg = warnings.length > 0
    ? `Đã nạp ${questions.length} câu hỏi hợp lệ (bỏ qua ${warnings.length} câu thiếu đáp án/lỗi định dạng ở trên). Đang mở bài làm...`
    : `Đã nạp thành công 100% (${questions.length} câu hỏi)! Đang khởi động bài làm...`;

  showImportStatus(successMsg, 'success');

  setTimeout(() => {
    closeImportModal();
    updateExamStatusBar(true);
    restartQuiz();
  }, warnings.length > 0 ? 1800 : 900);
}

function showImportStatus(text, type) {
  const msgBox = document.getElementById("import-msg");
  msgBox.textContent = text;
  msgBox.className = `import-msg ${type}`;
}
